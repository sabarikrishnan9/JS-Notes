const email = document.querySelector('#email');
const password = document.querySelector('#password');
const form = document.querySelector('#form');
const errorElement = document.querySelector('.error');

form.addEventListener('submit', (e) => {

    e.preventDefault();
        validateInputs()
});

function validateInputs() {
    const emailVal = email.value.trim();
    const passwordVal = password.value.trim();
    let success = true;

    if (emailVal === '') {
        success = false;
        setError(email, 'Email is required');
    } else if (!validateEmail(emailVal)) {
        success = false;
        setError(email, 'Please enter a valid email');
    } else {
        setSuccess(email,'Correct!!');
    }

    if (passwordVal === '') {
        success = false;
        setError(password, 'Password is required');
    } else if (passwordVal.length < 8) {
        success = false;
        setError(password, 'Password must be at least 8 characters');
    } else {
        setSuccess(password,'Correct!!');
    }
 
    return success;
}

function setError(element, message) {
    const inputGroup = element.parentElement;
    const errorElement = inputGroup.querySelector('.error');

    errorElement.innerText = message;

    inputGroup.classList.add('error');
    inputGroup.classList.remove('sucess');

    // console.log(message);

}

function setSuccess(element,message) {
    const inputGroup = element.parentElement;
    const errorElement = inputGroup.querySelector('.sucess');

    errorElement.innerText = message;
   
    inputGroup.classList.add('sucess');
    inputGroup.classList.remove('error');
    // console.log('sucess');

    

    
}

const validateEmail = (email) => {
    return String(email)
        .toLowerCase()
        .match(
            /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
};
