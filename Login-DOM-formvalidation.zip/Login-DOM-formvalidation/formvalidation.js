var left = document.createElement('div');
left.className = 'left';

var left_pad = document.createElement('div');
left_pad.className = 'left-pad';

var broad_lines = document.createElement('p');
broad_lines.className = ('broad-lines');

var image1 = document.createElement('img');
image1.src = 'play-button-arrowhead.png';
image1.alt = 'play-button';
image1.style.width = "25px";

var bold_1 = document.createElement('b');
bold_1.appendChild(document.createTextNode('Digital platform for distance'))

var learning1 = document.createElement('span');
learning1.className = 'learning';
learning1.appendChild(document.createTextNode('learning.'))
// learning.className = 'learning';



broad_lines.appendChild(image1);
broad_lines.appendChild(bold_1);
broad_lines.appendChild(learning1);


var you_will = document.createElement('span');
you_will.appendChild(document.createTextNode('You will never know everything.'));
you_will.className = 'you-will';

var brake_1 = document.createElement('br');
you_will.appendChild(brake_1);

you_will.appendChild(document.createTextNode('But you will know more '));

left_pad.appendChild(you_will);
left_pad.appendChild(broad_lines);


left.appendChild(left_pad);

document.body.appendChild(left);






var right = document.createElement('div');
right.className = 'right';

var right_pad = document.createElement('div');
right_pad.className = 'right-pad';

var image2 = document.createElement('img');
image2.setAttribute('src', 'spiral.png')
image2.className = 'spiral';
image2.alt = 'spiral';
image2.width = '45px';

let h2_1 = document.createElement('h2');
h2_1.style.fontFamily = "Arial, Helvetica, sans-serif";
h2_1.style.marginBottom = '4px';
h2_1.style.fontSize = 'xxx-large';

let b1 = document.createElement('b');
b1.appendChild(document.createTextNode('Hey,hello'))

let image3 = document.createElement('img');
image3.setAttribute("src", "wave.png");
image3.alt = "wave";
image3.width = "40px";

h2_1.appendChild(image3);
h2_1.appendChild(b1);


let Enter_the = document.createElement('span');
Enter_the.appendChild(document.createTextNode('Enter the information you entered while registering.'));

let brake_10 = document.createElement('br');

let brake_11 = document.createElement('br');

let form_1 = document.createElement('form');
form_1.setAttribute('id', 'form');

let input_group = document.createElement('div')
input_group.className = 'input-group';

let label_1 = document.createElement('label');
label_1.style.fontFamily = 'Cambria, Cochin, Georgia, Times, Times New Roman, serif';
label_1.appendChild(document.createTextNode('Email'));

let brake_2 = document.createElement('br');

let input_1 = document.createElement('input');
input_1.className = 'email';
input_1.type = 'text';
input_1.name = 'email';
input_1.setAttribute('id', 'email')
let error_1 = document.createElement('div');
error_1.className = 'error';
let sucess_1 = document.createElement('div');
sucess_1.className = 'sucess';
let brake_3 = document.createElement('br');
let brake_4 = document.createElement('br');


input_group.appendChild(label_1);
input_group.appendChild(brake_2);
input_group.appendChild(input_1);
input_group.appendChild(error_1);
input_group.appendChild(sucess_1);
input_group.appendChild(brake_3);
input_group.appendChild(brake_4);


let input_group_2 = document.createElement('div');
input_group.className = 'input-group';

let label_2 = document.createElement('label');
label_2.style.fontFamily = " Cambria, Cochin, Georgia, Times,";
label_2.appendChild(document.createTextNode('Password'));

let brake_5 = document.createElement('br');

let input_2 = document.createElement('input');
input_2.className = 'password';
input_2.type = 'password';
input_2.name = 'password';
input_2.setAttribute('id', 'password');


let error_2 = document.createElement('div');
error_2.className = 'error';
let sucess_2 = document.createElement('div');
sucess_2.className = 'sucess';
let brake_6 = document.createElement('br');



input_group_2.appendChild(label_2);
input_group_2.appendChild(brake_5);
input_group_2.appendChild(input_2);
input_group_2.appendChild(error_2);
input_group_2.appendChild(sucess_2);
input_group_2.appendChild(brake_6);


let check_box = document.createElement('input');
check_box.className = 'check-box';
check_box.type = 'checkbox';

let remember_me = document.createElement('label');
remember_me.className = 'remember-me';
remember_me.style.fontFamily = 'Arial, Helvetica, sans-serif; font-size: small';
remember_me.style.verticalAlign = 'middle';
remember_me.appendChild(document.createTextNode('Remember me'));


let Forgot_password = document.createElement('a');
Forgot_password.className = 'Forgot-password';
Forgot_password.href = '#';
Forgot_password.appendChild(document.createTextNode('Forgot password?'));

let brake_8 = document.createElement('br');

let log_in = document.createElement('button');
log_in.className = 'log-in';
log_in.setAttribute('id', 'login');
log_in.type = 'submit';
log_in.appendChild(document.createTextNode('Login'));


form_1.appendChild(input_group);
form_1.appendChild(input_group_2);
form_1.appendChild(check_box);
form_1.appendChild(remember_me);
form_1.appendChild(Forgot_password);
form_1.appendChild(brake_8);
form_1.appendChild(log_in);

let brake_9 = document.createElement('br');
let hr_1 = document.createElement('hr');
hr_1.className = 'below-login';
let span_1 = document.createElement('span');
span_1.className = 'or';
span_1.appendChild(document.createTextNode('or'));
let hr_2 = document.createElement('hr');
hr_2.className = 'below-login';

let signin_1 = document.createElement('button');
signin_1.className = 'signin';
let image4 = document.createElement('img');
image4.className = 'google-icon';
image4.src = 'google icon.png';
image4.width = '15px';
signin_1.appendChild(document.createTextNode('Sign in with Google'));


signin_1.appendChild(image4);


right_pad.appendChild(image2);
right_pad.appendChild(h2_1);
right_pad.appendChild(Enter_the);
right_pad.appendChild(brake_10);
right_pad.appendChild(brake_11);

right_pad.appendChild(form_1);

right_pad.appendChild(brake_9);
right_pad.appendChild(hr_1);
right_pad.appendChild(span_1);
right_pad.appendChild(hr_2);
right_pad.appendChild(signin_1);


right.appendChild(right_pad);

document.body.appendChild(right);